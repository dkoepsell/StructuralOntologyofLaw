@echo off
REM ============================================================
REM SOoL Corpus Monthly Update Script — Windows
REM SEAL Lab, Texas A&M University
REM David R. Koepsell — A Structural Ontology of the Law
REM ============================================================
REM Usage: Double-click or run from Command Prompt
REM
REM Set your API keys before running:
REM   set SOOL_CL_KEY=your-courtlistener-token
REM   set SOOL_ANTHROPIC_KEY=sk-ant-api03-...
REM Or create a file keys.bat in this directory with those two lines.
REM ============================================================

cd /d "%~dp0"

IF EXIST keys.bat (
    call keys.bat
)

IF "%SOOL_CL_KEY%"=="" (
    echo ERROR: SOOL_CL_KEY not set.
    echo Create keys.bat with:
    echo   set SOOL_CL_KEY=your-courtlistener-token
    echo   set SOOL_ANTHROPIC_KEY=sk-ant-api03-...
    pause
    exit /b 1
)

IF EXIST venv\Scripts\activate.bat (
    call venv\Scripts\activate.bat
)

echo ============================================================
echo SOoL Corpus Update — %DATE% %TIME%
echo ============================================================

echo.
echo Step 1: Collecting new cases...
python collect_caselaw.py --api-key %SOOL_CL_KEY% --domain all --limit 999 --texts

echo.
echo Step 2: Exporting JSONL...
python collect_caselaw.py --api-key %SOOL_CL_KEY% --export

echo.
echo Step 3: Annotating new cases...
python annotate_pipeline.py --api-key %SOOL_ANTHROPIC_KEY% --domain all

echo.
echo Step 4: Fixing mixed-perspective errors...
python annotate_pipeline.py --api-key %SOOL_ANTHROPIC_KEY% --reannotate-mixed

echo.
echo Step 5: Exporting corpus JSON...
python export_corpus.py

echo.
echo Step 6: Running analysis scripts...
python temporal_cd.py
python node_topology.py

echo.
echo ============================================================
echo Update complete — %DATE% %TIME%
echo ============================================================
pause
