#!/usr/bin/env python3
"""
SOoL Temporal CD Analysis
==========================
SEAL Lab, Texas A&M University
David R. Koepsell, A Structural Ontology of the Law (Palgrave, forthcoming)

Generates mean Contradiction Debt by domain by year (1990–2024).
Outputs:
  - sool_temporal_cd.png  (publication figure, 300 DPI)
  - sool_temporal_cd.json (data for HTML interactive chart)

Usage:
    python3 temporal_cd.py
    python3 temporal_cd.py --db ./sool_annotations.db --smooth 3
"""

import sqlite3, json, argparse, sys
from collections import defaultdict
from pathlib import Path

# ── ARGS ─────────────────────────────────────────────────────────────────────
parser = argparse.ArgumentParser()
parser.add_argument("--db",     default="./sool_annotations.db")
parser.add_argument("--out",    default=".")
parser.add_argument("--smooth", type=int, default=3,
                    help="Rolling average window in years (0 = no smoothing)")
parser.add_argument("--min-n",  type=int, default=3,
                    help="Minimum cases per year-domain cell to plot")
args = parser.parse_args()

# ── DATA EXTRACTION ───────────────────────────────────────────────────────────
conn = sqlite3.connect(args.db)
conn.row_factory = sqlite3.Row

rows = conn.execute("""
    SELECT domain_id, domain_name,
           CAST(SUBSTR(date_decided, 1, 4) AS INTEGER) AS year,
           contradiction_debt
    FROM annotations
    WHERE date_decided IS NOT NULL
      AND date_decided != ''
      AND contradiction_debt IS NOT NULL
      AND NOT needs_review
      AND CAST(SUBSTR(date_decided, 1, 4) AS INTEGER) BETWEEN 1990 AND 2024
    ORDER BY domain_id, year
""").fetchall()

print(f"Loaded {len(rows)} clean annotations with dates")

# ── AGGREGATE ─────────────────────────────────────────────────────────────────
DOMAIN_META = {
    1: {"name": "D1 First Amendment",       "color": "#8B1A1A"},
    2: {"name": "D2 Employment Discrim.",    "color": "#C9A84C"},
    3: {"name": "D3 Administrative Law",     "color": "#1B3C6E"},
    4: {"name": "D4 Criminal Procedure",     "color": "#7A3B00"},
    5: {"name": "D5 Immigration",            "color": "#5C1A7A"},
    6: {"name": "D6 Civil Rights §1983",     "color": "#1A5C2E"},
    7: {"name": "D7 Contract",               "color": "#888888"},
    8: {"name": "D8 Family Law",             "color": "#2E5C7A"},
}

# domain → year → [cd values]
cells = defaultdict(lambda: defaultdict(list))
for r in rows:
    cells[r["domain_id"]][r["year"]].append(r["contradiction_debt"])

# Build year × domain mean CD table
years = list(range(1990, 2025))
series = {}
for did, meta in DOMAIN_META.items():
    vals = []
    for y in years:
        cds = cells[did][y]
        if len(cds) >= args.min_n:
            vals.append({"year": y, "cd": sum(cds)/len(cds), "n": len(cds)})
        else:
            vals.append({"year": y, "cd": None, "n": len(cds)})
    series[did] = vals

# Rolling average smoothing
def smooth(vals, w):
    if w <= 1:
        return vals
    result = []
    cds = [v["cd"] for v in vals]
    for i, v in enumerate(vals):
        window = [c for c in cds[max(0,i-w//2):i+w//2+1] if c is not None]
        result.append({**v, "cd_smooth": sum(window)/len(window) if window else None})
    return result

for did in series:
    series[did] = smooth(series[did], args.smooth)

# ── EXPORT JSON ───────────────────────────────────────────────────────────────
payload = {
    "years": years,
    "domains": {
        str(did): {
            "name":  DOMAIN_META[did]["name"],
            "color": DOMAIN_META[did]["color"],
            "data":  [{"year": v["year"],
                       "cd":   round(v["cd"], 4) if v["cd"] else None,
                       "cd_smooth": round(v.get("cd_smooth", v["cd"] or 0), 4) if v.get("cd_smooth") or v["cd"] else None,
                       "n":    v["n"]} for v in series[did]]
        }
        for did in DOMAIN_META
    },
    "events": [
        {"year": 2006, "label": "Garcetti v. Ceballos", "domain": 1},
        {"year": 2010, "label": "Citizens United",       "domain": 1},
        {"year": 2019, "label": "Janus v. AFSCME",      "domain": 1},
        {"year": 2007, "label": "Bell Atlantic v. Twombly","domain":None},
        {"year": 2015, "label": "Chevron challenged",    "domain": 3},
        {"year": 2024, "label": "Loper Bright",          "domain": 3},
    ]
}

json_path = Path(args.out) / "sool_temporal_cd.json"
with open(json_path, "w") as f:
    json.dump(payload, f, indent=2)
print(f"JSON exported: {json_path}")

# Print summary table
print("\n── Mean CD by Domain by Decade ──────────────────────────────")
print(f"{'Domain':<30} {'1990s':>8} {'2000s':>8} {'2010s':>8} {'2020s':>8}")
for did, meta in DOMAIN_META.items():
    vals = series[did]
    def decade_avg(start, end):
        cds = [v["cd"] for v in vals if start <= v["year"] < end and v["cd"]]
        return f"{sum(cds)/len(cds):.3f}" if cds else "  —  "
    print(f"  {meta['name']:<28} {decade_avg(1990,2000):>8} {decade_avg(2000,2010):>8} "
          f"{decade_avg(2010,2020):>8} {decade_avg(2020,2025):>8}")

# ── MATPLOTLIB CHART ─────────────────────────────────────────────────────────
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    from matplotlib.lines import Line2D
    import numpy as np

    fig, (ax, ax2) = plt.subplots(2, 1, figsize=(14, 10),
                                   gridspec_kw={"height_ratios": [3, 1]},
                                   facecolor="#F5F1E8")
    ax.set_facecolor("#F5F1E8")
    ax2.set_facecolor("#F5F1E8")

    # ── Main chart ──────────────────────────────────────────────────────────
    for did, meta in DOMAIN_META.items():
        vals = series[did]
        ys = [v["year"] for v in vals if v.get("cd_smooth") is not None]
        cds = [v["cd_smooth"] for v in vals if v.get("cd_smooth") is not None]
        ns  = [v["n"] for v in vals if v.get("cd_smooth") is not None]

        if not ys:
            continue

        lw = 2.5 if did == 1 else (2.0 if did == 3 else 1.5)
        alpha = 1.0 if did in (1,3,4) else 0.7
        zorder = 5 if did in (1,3) else 3

        ax.plot(ys, cds, color=meta["color"], linewidth=lw,
                label=meta["name"], alpha=alpha, zorder=zorder)

        # Scatter with size proportional to n
        sizes = [max(20, min(120, n*4)) for n in ns]
        ax.scatter(ys, cds, color=meta["color"], s=sizes, alpha=0.5*alpha,
                   zorder=zorder+1, linewidths=0)

    # ── Event annotations ───────────────────────────────────────────────────
    events = [
        (2006, "Garcetti\nv. Ceballos", 0.32, "#8B1A1A"),
        (2024, "Loper\nBright",          0.26, "#1B3C6E"),
        (2019, "Janus",                  0.30, "#8B1A1A"),
    ]
    for year, label, y_ann, color in events:
        ax.axvline(year, color=color, linestyle="--", linewidth=1.0, alpha=0.5, zorder=2)
        ax.annotate(label, xy=(year, y_ann), xytext=(year+0.4, y_ann),
                    fontsize=8, color=color, fontweight="bold",
                    va="center", fontfamily="serif")

    # ── Overall corpus mean ─────────────────────────────────────────────────
    all_by_year = defaultdict(list)
    for r in rows:
        try:
            y = int(r["date_decided"][:4])
            all_by_year[y].append(r["contradiction_debt"])
        except: pass
    mean_ys  = sorted([y for y,v in all_by_year.items() if len(v)>=5])
    mean_cds = [sum(all_by_year[y])/len(all_by_year[y]) for y in mean_ys]
    # Smooth
    def roll(xs, w=3):
        out = []
        for i in range(len(xs)):
            sl = xs[max(0,i-w//2):i+w//2+1]
            out.append(sum(sl)/len(sl))
        return out
    ax.plot(mean_ys, roll(mean_cds), color="#333333", linewidth=2.5,
            linestyle=":", label="All-domain mean", zorder=6, alpha=0.8)

    ax.set_xlim(1989, 2025)
    ax.set_ylim(0.05, 0.45)
    ax.set_ylabel("Mean Contradiction Debt (CD)", fontsize=11, fontfamily="serif",
                  color="#1B3C6E", fontweight="bold")
    ax.set_title("Contradiction Debt by Doctrinal Domain, 1990–2024",
                 fontsize=14, fontfamily="serif", color="#1B3C6E",
                 fontweight="bold", pad=12)
    ax.tick_params(labelsize=9, colors="#555555")
    ax.spines[["top","right"]].set_visible(False)
    ax.spines[["left","bottom"]].set_color("#C8B898")
    ax.yaxis.grid(True, color="#E0D4B8", linewidth=0.8, linestyle="--")
    ax.set_axisbelow(True)

    # Shaded regions for key periods
    ax.axvspan(2006, 2008, alpha=0.06, color="#8B1A1A", zorder=1)
    ax.axvspan(2023, 2024.5, alpha=0.06, color="#1B3C6E", zorder=1)

    leg = ax.legend(fontsize=8.5, framealpha=0.9, fancybox=False,
                    edgecolor="#C8B898", loc="upper right",
                    prop={"family":"serif"})

    # ── Case count bar chart ────────────────────────────────────────────────
    year_ns = sorted(all_by_year.keys())
    bar_ns  = [len(all_by_year[y]) for y in year_ns]
    ax2.bar(year_ns, bar_ns, color="#1B3C6E", alpha=0.4, width=0.8)
    ax2.set_xlim(1989, 2025)
    ax2.set_ylabel("Cases / year", fontsize=9, fontfamily="serif", color="#555555")
    ax2.set_xlabel("Year", fontsize=10, fontfamily="serif", color="#555555")
    ax2.tick_params(labelsize=8, colors="#555555")
    ax2.spines[["top","right"]].set_visible(False)
    ax2.spines[["left","bottom"]].set_color("#C8B898")
    ax2.yaxis.grid(True, color="#E0D4B8", linewidth=0.6)
    ax2.set_axisbelow(True)

    # Footer
    fig.text(0.5, 0.01,
        "SEAL Lab · Texas A&M University · Koepsell (2026) · "
        "A Structural Ontology of the Law (Palgrave, forthcoming) · "
        f"n={len(rows)} clean annotations · {args.smooth}-year rolling average",
        ha="center", fontsize=7.5, color="#888888", fontfamily="serif")

    plt.tight_layout(rect=[0, 0.03, 1, 1])
    png_path = Path(args.out) / "sool_temporal_cd.png"
    plt.savefig(png_path, dpi=300, bbox_inches="tight",
                facecolor="#F5F1E8")
    plt.close()
    print(f"Chart saved: {png_path}")

except ImportError:
    print("matplotlib not installed — JSON exported only.")
    print("Install: pip install matplotlib")
    print("Then re-run to generate the PNG figure.")
