#!/usr/bin/env python3
"""
SOoL Node Failure Topology Analysis
=====================================
SEAL Lab, Texas A&M University
David R. Koepsell, A Structural Ontology of the Law (Palgrave, forthcoming)

Computes the co-occurrence matrix of node failures across the annotated corpus,
compares it against the theoretical MLC dependency graph, and exports:
  - sool_node_topology.json   (for interactive HTML visualization)
  - sool_node_topology.png    (publication figure, 300 DPI)

A "failure" = node closure is 'failed' or 'partial' (both represent
non-closure; partial is a graded failure).

Usage:
    python3 node_topology.py
    python3 node_topology.py --db ./sool_annotations.db --partial-as-failure
"""

import sqlite3, json, argparse, math
from collections import defaultdict
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--db",  default="./sool_annotations.db")
parser.add_argument("--out", default=".")
parser.add_argument("--partial-as-failure", action="store_true", default=True,
    help="Count 'partial' closures as failures (default: True)")
parser.add_argument("--domain", default="all",
    help="Domain filter: 'all' or comma-separated domain IDs")
args = parser.parse_args()

# ── DATA EXTRACTION ───────────────────────────────────────────────────────────
conn = sqlite3.connect(args.db)
conn.row_factory = sqlite3.Row

domain_filter = ""
if args.domain != "all":
    ids = [int(x.strip()) for x in args.domain.split(",")]
    domain_filter = f"AND domain_id IN ({','.join(str(i) for i in ids)})"

rows = conn.execute(f"""
    SELECT
        node1_closure, node2_closure, node3_closure, node4_closure,
        node5_closure, node6_closure, node7_closure, node8_closure,
        domain_id, chain_outcome, contradiction_debt
    FROM annotations
    WHERE NOT needs_review
    {domain_filter}
""").fetchall()

print(f"Loaded {len(rows)} clean annotations")

FAIL_STATES = {"failed", "partial"} if args.partial_as_failure else {"failed"}
NODE_COLS   = [f"node{n}_closure" for n in range(1,9)]
NODE_NAMES  = [
    "N1 Source of\nAuthority",
    "N2 Norm",
    "N3 Actor\nin Role",
    "N4 Triggering\nFacts",
    "N5 Legal Act /\nOmission",
    "N6 Target",
    "N7 Legal\nEffect",
    "N8 Remedy",
]
NODE_SHORT = ["N1","N2","N3","N4","N5","N6","N7","N8"]
CLUSTERS   = ["AUTHORITY","AUTHORITY","AUTHORITY","EFFECT","EFFECT",
              "RECOGNITION","RECOGNITION","REPAIR"]

# ── CO-OCCURRENCE MATRIX ──────────────────────────────────────────────────────
# cooccur[i][j] = cases where BOTH node i+1 and node j+1 failed
N = 8
cooccur   = [[0]*N for _ in range(N)]
fail_count = [0]*N   # marginal failure count per node
total      = len(rows)

for row in rows:
    failed = [1 if (row[NODE_COLS[n]] or "").lower() in FAIL_STATES else 0
              for n in range(N)]
    for i in range(N):
        if failed[i]:
            fail_count[i] += 1
        for j in range(i, N):
            if failed[i] and failed[j]:
                cooccur[i][j] += 1
                if i != j:
                    cooccur[j][i] += 1  # symmetric

# Normalize to conditional probability: P(j fails | i fails)
cond_prob = [[0.0]*N for _ in range(N)]
for i in range(N):
    for j in range(N):
        if fail_count[i] > 0:
            cond_prob[i][j] = cooccur[i][j] / fail_count[i]

# Phi coefficient (corrected correlation for binary variables)
phi = [[0.0]*N for _ in range(N)]
for i in range(N):
    for j in range(N):
        if i == j:
            phi[i][j] = 1.0
            continue
        n11 = cooccur[i][j]
        n10 = fail_count[i] - n11
        n01 = fail_count[j] - n11
        n00 = total - n11 - n10 - n01
        denom = math.sqrt(
            (n11+n10)*(n11+n01)*(n00+n10)*(n00+n01)
        )
        phi[i][j] = (n11*n00 - n10*n01) / denom if denom > 0 else 0.0

# ── THEORETICAL DEPENDENCY GRAPH ─────────────────────────────────────────────
# Edges from the MLC theoretical architecture
# (source, target, type, description)
THEORETICAL_EDGES = [
    (0,1,"sequential","N1→N2: Authority generates Norm"),
    (1,2,"sequential","N2→N3: Norm vests Actor in Role"),
    (0,2,"conferral","N1→N3: Conferral Failure link"),
    (3,4,"sequential","N4→N5: Facts activate Act"),
    (1,5,"jurisdictional","N2→N6: Jurisdictional Contradiction link"),
    (1,4,"procedural","N2→N5: Procedural Contradiction link"),
    (5,6,"sequential","N6→N7: Target receives Legal Effect"),
    (6,7,"cascade","N7→N8: RPF cascade (if N7 fails, N8 must fail)"),
    (1,3,"indeterminacy","N2↔N3: NI and RC3 structurally coupled"),
]

# ── COMPARE THEORY TO EMPIRICS ────────────────────────────────────────────────
print("\n── Co-occurrence Matrix (raw counts) ───────────────────────────────────")
header = "     " + "  ".join(f"N{i+1:>4}" for i in range(N))
print(header)
for i in range(N):
    row_str = f"N{i+1}  " + "  ".join(f"{cooccur[i][j]:>5}" for j in range(N))
    print(row_str)

print("\n── Phi Correlation Matrix ───────────────────────────────────────────────")
print(header)
for i in range(N):
    row_str = f"N{i+1}  " + "  ".join(f"{phi[i][j]:>5.3f}" for j in range(N))
    print(row_str)

print("\n── Node Failure Rates ───────────────────────────────────────────────────")
for i in range(N):
    rate = fail_count[i]/total
    bar  = "█"*int(rate*40) + "░"*(40-int(rate*40))
    print(f"  N{i+1} {NODE_NAMES[i].replace(chr(10),' '):<30} {fail_count[i]:>5}/{total}  "
          f"({rate:.1%})  {bar}")

print("\n── Theoretical Prediction Test ──────────────────────────────────────────")
print("Testing: upstream co-occurrences should exceed cross-cluster co-occurrences")
print()

# Upstream pairs (same cluster, theoretically coupled)
upstream_pairs = [(1,2,"N2+N3 (NI+RC3, Authority)"),
                  (0,1,"N1+N2 (CF+NI, Authority)"),
                  (5,6,"N6+N7 (RF, Recognition)"),
                  (6,7,"N7+N8 (RPF cascade, must co-occur)")]
# Cross-cluster pairs (theoretically decoupled)
cross_pairs    = [(1,7,"N2+N8 (Norm + Repair, cross-cluster)"),
                  (2,7,"N3+N8 (Role + Repair, cross-cluster)"),
                  (3,6,"N4+N7 (Facts + Effect, cross-cluster)"),
                  (0,7,"N1+N8 (Authority + Repair, cross-cluster)")]

print("  Upstream/coupled pairs:")
for i,j,label in upstream_pairs:
    print(f"    {label:<45} phi={phi[i][j]:>6.3f}  "
          f"P(j|i)={cond_prob[i][j]:.3f}")

print("\n  Cross-cluster/decoupled pairs:")
for i,j,label in cross_pairs:
    print(f"    {label:<45} phi={phi[i][j]:>6.3f}  "
          f"P(j|i)={cond_prob[i][j]:.3f}")

# Test hypothesis
up_phi  = [phi[i][j] for i,j,_ in upstream_pairs if i!=j]
cr_phi  = [phi[i][j] for i,j,_ in cross_pairs  if i!=j]
mean_up = sum(up_phi)/len(up_phi)
mean_cr = sum(cr_phi)/len(cr_phi)
print(f"\n  Mean phi — upstream pairs:      {mean_up:.4f}")
print(f"  Mean phi — cross-cluster pairs: {mean_cr:.4f}")
print(f"  Ratio: {mean_up/mean_cr:.2f}x")
print()
if mean_up > mean_cr:
    print("  ✓ CONFIRMS structural universality hypothesis:")
    print("    Co-occurrence topology matches MLC theoretical dependency graph.")
    print("    Upstream node failures co-occur more strongly than cross-cluster failures.")
else:
    print("  ✗ DOES NOT CONFIRM: cross-cluster co-occurrence exceeds upstream.")
    print("    Inspect domain-specific patterns for confounds.")

# ── EXPORT JSON ───────────────────────────────────────────────────────────────
payload = {
    "n_cases":    total,
    "nodes": [
        {"id": i, "short": NODE_SHORT[i], "name": NODE_NAMES[i],
         "cluster": CLUSTERS[i], "fail_count": fail_count[i],
         "fail_rate": round(fail_count[i]/total, 4)}
        for i in range(N)
    ],
    "cooccur": cooccur,
    "phi":     [[round(phi[i][j], 4) for j in range(N)] for i in range(N)],
    "cond_prob":[[round(cond_prob[i][j],4) for j in range(N)] for i in range(N)],
    "theoretical_edges": THEORETICAL_EDGES,
    "stats": {
        "mean_phi_upstream":     round(mean_up, 4),
        "mean_phi_cross":        round(mean_cr, 4),
        "ratio":                 round(mean_up/mean_cr, 3) if mean_cr else None,
        "confirms_hypothesis":   mean_up > mean_cr,
    }
}

json_path = Path(args.out) / "sool_node_topology.json"
with open(json_path, "w") as f:
    json.dump(payload, f, indent=2)
print(f"\nJSON exported: {json_path}")
print("Load this into the HTML interactive visualization.")

# ── MATPLOTLIB FIGURE ─────────────────────────────────────────────────────────
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    import numpy as np

    fig, axes = plt.subplots(1, 2, figsize=(14, 7), facecolor="#F5F1E8")
    ax1, ax2  = axes

    # ── Left: phi correlation heatmap ────────────────────────────────────────
    phi_arr = np.array(phi)
    labels  = [s.replace("\n"," ") for s in NODE_SHORT]

    im = ax1.imshow(phi_arr, cmap="RdYlBu_r", vmin=-0.2, vmax=1.0,
                    aspect="auto")
    ax1.set_xticks(range(N)); ax1.set_xticklabels(labels, fontsize=9,
                                                    fontfamily="serif")
    ax1.set_yticks(range(N)); ax1.set_yticklabels(labels, fontsize=9,
                                                    fontfamily="serif")
    for i in range(N):
        for j in range(N):
            val = phi[i][j]
            color = "white" if val > 0.5 else "black"
            ax1.text(j, i, f"{val:.2f}", ha="center", va="center",
                     fontsize=7.5, color=color, fontfamily="serif")

    # Cluster boundaries
    for boundary in [2.5, 4.5, 6.5]:
        ax1.axhline(boundary, color="#C9A84C", linewidth=1.5)
        ax1.axvline(boundary, color="#C9A84C", linewidth=1.5)

    plt.colorbar(im, ax=ax1, shrink=0.8, label="Phi correlation")
    ax1.set_title("Node Failure Co-occurrence\n(Phi correlation matrix)",
                  fontsize=11, fontfamily="serif", color="#1B3C6E", fontweight="bold")
    ax1.set_facecolor("#F5F1E8")

    # Cluster labels
    cluster_positions = [(1.0,"AUTHORITY"),(3.5,"EFFECT"),(5.5,"RECOG."),(7,"REPAIR")]
    for pos, label in cluster_positions:
        ax1.text(-1.3, pos, label, fontsize=7, fontfamily="serif",
                 color="#7A5500", fontweight="bold", va="center", rotation=90)

    # ── Right: network graph ─────────────────────────────────────────────────
    ax2.set_facecolor("#F5F1E8")
    ax2.set_xlim(-0.3, 1.3)
    ax2.set_ylim(-0.3, 1.2)
    ax2.axis("off")
    ax2.set_title("MLC Node Failure Network\n(edge weight = phi correlation)",
                  fontsize=11, fontfamily="serif", color="#1B3C6E", fontweight="bold")

    # Node positions (roughly matching MLC flow)
    POSITIONS = [
        (0.1, 0.85),  # N1
        (0.4, 0.85),  # N2
        (0.7, 0.85),  # N3
        (0.15,0.45),  # N4
        (0.45,0.45),  # N5
        (0.55,0.10),  # N6
        (0.75,0.10),  # N7
        (0.95,0.10),  # N8
    ]

    CLUSTER_COLORS = {
        "AUTHORITY":   "#1B3C6E",
        "EFFECT":      "#7A5500",
        "RECOGNITION": "#1A5C2E",
        "REPAIR":      "#5C1A7A",
    }

    # Draw edges weighted by phi
    phi_min = 0.15  # threshold
    for i in range(N):
        for j in range(i+1, N):
            if phi[i][j] >= phi_min:
                x1,y1 = POSITIONS[i]
                x2,y2 = POSITIONS[j]
                width = phi[i][j] * 8
                alpha = min(0.9, phi[i][j] * 1.5)
                color = "#C9A84C" if phi[i][j] > 0.6 else "#888888"
                ax2.plot([x1,x2],[y1,y2], color=color,
                         linewidth=width, alpha=alpha, zorder=1)

    # Draw theoretical edges (dashed)
    for src,tgt,etype,_ in THEORETICAL_EDGES:
        x1,y1 = POSITIONS[src]
        x2,y2 = POSITIONS[tgt]
        ax2.annotate("", xy=(x2,y2), xytext=(x1,y1),
                     arrowprops=dict(arrowstyle="->", color="#C9A84C",
                                     lw=1.5, linestyle="dashed"),
                     zorder=2)

    # Draw nodes
    for i in range(N):
        x,y = POSITIONS[i]
        clr = CLUSTER_COLORS[CLUSTERS[i]]
        size = 800 + fail_count[i]/total * 2000
        ax2.scatter(x, y, s=size, color=clr, zorder=3,
                    edgecolors="white", linewidths=2, alpha=0.9)
        ax2.text(x, y, NODE_SHORT[i], ha="center", va="center",
                 fontsize=9, fontfamily="serif", color="white",
                 fontweight="bold", zorder=4)
        rate = fail_count[i]/total
        ax2.text(x, y-0.09, f"{rate:.0%}", ha="center", va="top",
                 fontsize=7.5, fontfamily="serif", color=clr)

    # Legend
    for cluster, color in CLUSTER_COLORS.items():
        ax2.scatter([], [], color=color, s=100, label=cluster)
    ax2.legend(loc="upper right", fontsize=8, framealpha=0.8,
               prop={"family":"serif"}, title="Cluster",
               title_fontsize=8, edgecolor="#C8B898")

    # Footnote
    fig.text(0.5, 0.01,
        f"SEAL Lab · Texas A&M · Koepsell (2026) · "
        f"A Structural Ontology of the Law (Palgrave, forthcoming) · "
        f"n={total} clean annotations · "
        f"upstream phi={mean_up:.3f} vs cross-cluster phi={mean_cr:.3f} "
        f"({mean_up/mean_cr:.2f}× — {'CONFIRMS' if mean_up>mean_cr else 'DOES NOT CONFIRM'} structural universality hypothesis)",
        ha="center", fontsize=7, color="#888888", fontfamily="serif")

    plt.tight_layout(rect=[0, 0.03, 1, 1])
    png_path = Path(args.out) / "sool_node_topology.png"
    plt.savefig(png_path, dpi=300, bbox_inches="tight", facecolor="#F5F1E8")
    plt.close()
    print(f"Figure saved: {png_path}")

except ImportError:
    print("matplotlib not installed — JSON exported only.")
    print("pip install matplotlib numpy")
