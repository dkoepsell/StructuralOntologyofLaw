@echo off
echo SOoL Corpus Pipeline - Setup
echo ================================
cd /d "%~dp0"

python -m venv venv
call venv\Scripts\activate.bat
pip install requests tqdm scipy matplotlib numpy rdflib

mkdir "%USERPROFILE%\CaseLaw" 2>nul
copy scripts\*.py "%USERPROFILE%\CaseLaw\"
copy update_corpus.bat "%USERPROFILE%\CaseLaw\"
copy web\SOoL_QueryTool.html "%USERPROFILE%\CaseLaw\"
copy keys.bat "%USERPROFILE%\CaseLaw\"

echo.
echo Setup complete. Next steps:
echo 1. Edit CaseLaw\keys.bat with your API keys
echo 2. cd "%USERPROFILE%\CaseLaw" and run update_corpus.bat
pause
