@REM Copy this file to your CaseLaw directory and fill in your API keys
set SOOL_CL_KEY=YOUR_COURTLISTENER_TOKEN_HERE
set SOOL_ANTHROPIC_KEY=YOUR_ANTHROPIC_KEY_HERE
