#!/bin/bash
echo "SOoL Corpus Pipeline — Setup"
echo "================================"
cd "$(dirname "${BASH_SOURCE[0]}")"

# Create venv
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install requests tqdm scipy matplotlib numpy rdflib --break-system-packages 2>/dev/null || \
pip install requests tqdm scipy matplotlib numpy rdflib

# Copy scripts to working directory
mkdir -p ~/CaseLaw
cp scripts/*.py ~/CaseLaw/
cp update_corpus.sh ~/CaseLaw/
cp update_corpus.bat ~/CaseLaw/
cp web/SOoL_QueryTool.html ~/CaseLaw/
cp env_template.txt ~/CaseLaw/

echo ""
echo "Setup complete. Next steps:"
echo "1. Add your API keys to ~/.sool_env (see env_template.txt)"
echo "2. cd ~/CaseLaw && source ~/.sool_env"
echo "3. ./update_corpus.sh   (first run collects ~4,931 cases — takes ~15 hours)"
